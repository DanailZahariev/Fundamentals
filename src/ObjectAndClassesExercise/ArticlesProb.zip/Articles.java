public class Articles {
    private String article;
    private String content;
    private String author;

    public Articles(String article, String content, String author) {
        this.article = article;
        this.content = content;
        this.author = author;
    }

    public void edit(String newContent) {
        this.content = newContent;
    }

    public void change(String newAuthor) {
        this.author = newAuthor;
    }

    public void rename(String newTittle) {
        this.article = newTittle;
    }

    @Override
    public String toString() {
    return this.article + " - " + this.content + ": " + author;
    }
}
